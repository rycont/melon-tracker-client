<template>
  <h1>
    Melon Tracker
  </h1>
</template>

<script>
export default {
  name: 'header-title'
}
</script>

<style scoped>
  h1 {
    background-color: #00CD3C;
    color: white;
    margin: 0;
    padding: 12px;
    font-size: 15px;
    font-weight: 900;
    display: none;
  }
</style>