import store from '@/functions/db'
import {getRealtimeChart} from '@/functions/chart'
getRealtimeChart().then(console.log)